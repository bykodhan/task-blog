
<?php $__env->startSection('content'); ?>
    <div class="card text-bg-dark mb-2 rounded-0" style="max-height: 400px;">
        <img src=" <?php echo e(asset($post->img)); ?>" class="card-img" alt="..." loading="lazy" style="max-height: 400px;">
        <div class="card-img-overlay2 d-flex align-items-center" style="max-height: 400px;">
            <div class="d-flex flex-column text-white text-shadow-1  text-center mx-auto">
                <h2 class="display-4">
                    <?php echo e($post->title); ?>

                </h2>
                <div class="d-flex justify-content-center align-items-center gap-3">
                    <span>
                        Yazar : <?php echo e($post->user->email); ?>

                    </span>
                    <span>
                        <?php echo e(Carbon\Carbon::parse($post->created_at)->isoFormat('MMMM DD, YYYY')); ?>

                    </span>
                </div>

            </div>
        </div>
    </div>
    <section class="bg-light py-4 border-bottom">
        <div class="container">
            <div class="row">
                <div class="col-md-8">
                    <p class="lead">
                        <?php echo e($post->content); ?>

                    </p>
                </div>
                <div class="col-lg-4 text-center">
                    <div class="d-flex flex-column justify-content-center align-items-center">
                        <img loading="lazy" class="img-fluid rounded-circle"
                            src="https://play-lh.googleusercontent.com/UjaAdTYsArv7zAJbqGWjQw2ftuOtnAlvokffC3TQQ2K12mwk0YdXUF2wZBTBA2kDZIk"
                            style="max-width: 100px">
                        <h3 class="mt-3">
                            <?php echo e($post->user->email); ?>

                        </h3>
                        <span>
                            <?php echo e($post->user->posts->count()); ?> yazı
                        </span>
                    </div>
                    <hr>
                    <div class="d-flex flex-column justify-content-center align-items-center">
                        <h3 class="mt-3">
                            Kategoriler
                        </h3>
                        <div class="d-flex flex-column w-100 gap-2">
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="d-flex align-items-center justify-content-between">
                                    <?php echo e($category->category); ?> 
                                    <span>(<?php echo e($category->total); ?>)</span>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\asus\Desktop\works\task-blog\resources\views/front/post_show.blade.php ENDPATH**/ ?>