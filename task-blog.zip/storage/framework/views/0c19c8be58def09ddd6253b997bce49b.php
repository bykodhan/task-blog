<aside id="sidebar" class="sidebar">

    <ul class="sidebar-nav" id="sidebar-nav">

        <li class="nav-item">
            <a class="nav-link collapsed" href="<?php echo e(route('admin.index')); ?>">
                <i class="bi bi-grid"></i>
                <span>
                    <?php echo e(__('Panel')); ?>

                </span>
            </a>
        </li><!-- End Dashboard Nav -->

        <li class="nav-item">
            <a class="nav-link collapsed" data-bs-target="#components-nav" data-bs-toggle="collapse" href="#">
                <i class="bi bi-menu-button-wide"></i>
                <span>
                    <?php echo e(__('Yazılar')); ?>

                </span>
                <i
                    class="bi bi-chevron-down ms-auto"></i>
            </a>
            <ul id="components-nav" class="nav-content collapse " data-bs-parent="#sidebar-nav">
                <li>
                    <a href="<?php echo e(route('admin.posts.create')); ?>">
                        <i class="bi bi-circle"></i>
                        <span>
                            <?php echo e(__('Yeni Yazı Oluştur')); ?>

                        </span>
                    </a>
                </li>
                <li>
                    <a href="<?php echo e(route('admin.posts.index')); ?>">
                        <i class="bi bi-circle"></i>
                        <span>
                            <?php echo e(__('Tüm Yazılar')); ?>

                        </span>
                    </a>
                </li>
              
            </ul>
        </li><!-- End Components Nav -->

    </ul>

</aside><?php /**PATH C:\Users\asus\Desktop\works\task-blog\resources\views/back/layouts/sidebar.blade.php ENDPATH**/ ?>